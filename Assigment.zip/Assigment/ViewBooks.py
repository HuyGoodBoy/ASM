def view_books(book_list):
    cur=book_list.head
    print("Bid   |   Title   |   Author   |   Status")
    while cur:
        print("{:<6}   |   {:<9}   |   {:<10}   |   {}".format(cur.data.bid, cur.data.title, cur.data.author, cur.data.status))
        cur = cur.next

