def delete_book(bid,book_list):
    if book_list.head is None:
        return
    cur=book_list.head
    prev=None
    if cur.data.bid ==bid:
        book_list.head=cur.next
        cur=None
        return
    while cur:
        if cur.data.bid==bid:
            break
        prev=cur
        cur=cur.next
    if cur is None:
        return
    prev.next=cur.next
    cur=None
    
    