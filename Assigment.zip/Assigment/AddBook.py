from Book import *
from Node import *
def add_book(book_list):
    bid=input('Enter BookID: ')
    title= input('Enter Book Title: ')
    author=input("Enter Book's Author: ")
    status=input("Book's Status: '0' is available '1' is issued: ")
    new_book=Book(bid,title,author,status)
    new_node=Node(new_book)
    cur=book_list.head
    if cur is None:
        book_list.head=new_node
    else:
        while cur.next:
            cur=cur.next
        cur.next=new_node
