def return_book(book_list,bid):
    if book_list.head is None:
        return
    cur=book_list.head
    while cur:
        if cur.data.bid==bid and cur.data.status=='1':
            print('Return book successfully')
            cur.data.status='0'
            return
        cur=cur.next
    print('Not Found BookID')