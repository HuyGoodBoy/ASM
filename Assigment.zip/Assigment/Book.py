class Book:
    def __init__(self,bid,title,author,status,borrower=None):
        self.bid=bid
        self.title=title
        self.author=author
        self.status=status
        self.borrower=borrower
        pass