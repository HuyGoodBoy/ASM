from AddBook import add_book
from ViewBooks import view_books
from DeleteBook import delete_book
from BorrowedBook import borrow_book
from ReturnBook import return_book
from Node import *
book_list=LinkedList()
borrow_book_list=LinkedList()
def main():
    while True:
        print("1. Add book")
        print("2. View books")
        print("3. Delete book")
        print("4. Borrow book")
        print("5. Return book")
        print("6. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            add_book(book_list)
        elif choice == '2':
            view_books(book_list)
        elif choice == '3':
            bid=input('BookID want to delete: ')
            delete_book(bid,book_list)
        elif choice == '4':
            bid=input('BookID want to borrow: ')
            borrower=input('Borrower name: ')
            borrow_book(bid,borrower,book_list)
        elif choice == '5':
            bid=input('BookID want to return: ')
            return_book(book_list,bid)
        elif choice == '6':
            break
        else:
            print("Invalid choice. Please try again.")
if __name__ == "__main__":
    main()
