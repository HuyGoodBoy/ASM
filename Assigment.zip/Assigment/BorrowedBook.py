def borrow_book(bid,borrower,book_list):
    if book_list.head is None:
        return
    cur=book_list.head
    while cur:
        if cur.data.bid==bid and cur.data.status=='0':
            cur.data.status='1'
            cur.data.borrower=borrower
            print('You can borrow this book')
            return
        elif cur.data.bid==bid and cur.data.status=='1':
            print('The book has been borrowed')
            return
        cur=cur.next
    print('Not Found BookID')